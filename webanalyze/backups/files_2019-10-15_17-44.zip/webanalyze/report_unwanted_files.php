<?php die(); ?>
/newtest/vendor/sendgrid/sendgrid/prism_linux_amd64
/vendor/sendgrid/sendgrid/prism_linux_amd64
/newtest3/vendor/sendgrid/sendgrid/prism_linux_amd64
