<?php
define("ACCESS_KEY", "dd002054e9556576f6de24efb63cf2cb");
define("SCAN_SERVER_PATH", "");// e.g. for yii or similar CMS (!!! / in the end) e.g. /home/testacc/ 
?>
