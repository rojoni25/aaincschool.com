<?php die(); ?>
/demo.acquisitionallianceinc.com/vendor/sendgrid/sendgrid/prism_linux_amd64
