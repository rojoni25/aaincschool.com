<?php die(); ?>
["\/newtest\/vendor\/sendgrid\/sendgrid\/","\/vendor\/sendgrid\/sendgrid\/","\/newtest_final\/vendor\/sendgrid\/sendgrid\/"]